<?php
session_start();
include_once ("conexao.php");

$pdo = conectar();

$categoria = "SELECT * FROM tb_categorias";
$stmt = $pdo->prepare($categoria);
$stmt->execute();
$linhas = $stmt->fetchAll(PDO::FETCH_ASSOC);
//var_dump($linhas);
if(isset($_SESSION['logado'])):
    header("Location: pgAcesso.php");
endif;
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <title>Cadastro de Quartos</title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="/css/styleInserircopy.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comfortaa&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="icon" href="img/opicon1.png">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js">
</head>

<body>
    <script>
        function abrirMenu(){
            document.getElementById('barra_menu').style.width = "250px";
            document.getElementById('cadastro-box').style.marginLeft = "290px";
        
        };
        function fecharMenu(){
            document.getElementById('barra_menu').style.width = "0px";
            document.getElementById('cadastro-box').style.marginLeft = "83px";
        };

        $(document).ready(function(){
                $('.sub-btn').click(function(){
                   $(this).next('.sub-menu').slideToggle();
                   $(this).find('.dropdown').toggleClass('rotate');
                });
            });
    </script> 

<header class="cabecalho">
        <img src="/img/iconeMenu.png" alt="menu" class="icone_menu" onclick="abrirMenu()">
        <img src="img/iconeLogo.png" alt="Logo da Empresa" class="logo">
    </header>
    <div id="barra_menu">
            <img src="/img/iconeMenu.png" alt="menu" class="icone_menu_nav" onclick="fecharMenu()"></a>
            <div class="menu">
            <div class="item"><a href="homepg.php">Início</a></div>
                <div class="item"><a class="sub-btn">Hóspedes<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="insCliente.php" class="sub-item">Cadastrar Cliente</a>
                        <a href="conCliente.php" class="sub-item">Consultar</a>
                        <a href="barraPesquisaCliente.php" class="sub-item">Fazer uma busca</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Quartos<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="insQuarto.php" class="sub-item">Cadastrar Quarto</a>
                        <a href="conQuarto.php" class="sub-item">Consultar</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Categorias<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="inctb_categorias.php" class="sub-item">Cadastrar Categoria</a>
                        <a href="contb_categorias.php" class="sub-item">Consultar</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Reservas<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="geraAgenda.php" class="sub-item">Gerar Agenda</a>
                        <a href="agendar_adm.php" class="sub-item">Realizar Reserva</a>
                        <a href="desmarcar_adm.php" class="sub-item">Desmarcar Reserva</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Relatório<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="/menu_relatorios.php" class="sub-item">Por Status</a>
                    </div>
                </div>
                <div class="item"><a href="logout.php">Sair</a></div>
            </div>
    </div>
        <main id="cadastro-box">
            <h1 class="titulo-principal">Cadastro de Quarto</h1>
      <form method="post" enctype="multipart/form-data">
        <div class="form-group">
          <label>Nome Quarto</label>
          <input type= "text" name="nome_quarto" placeholder="Digite o nome do quarto" class="form-control col-4" required><br>
          <label>Categoria</label>
          <select name="fk_cod_categoria" class="form-control col-4" required><br>
            <option>Selecione</option>
                <?php foreach ($linhas as $l) { ?>
                    <option value="<?php echo $l['cod_categoria']; ?>"><?php echo $l['nome_categoria']; ?></option>
                <?php } ?>
            </select><br>
          <label>Número de camas de Casal</label>
          <input type="number" name="cama_casal" min="0"  placeholder="Nº" class="form-control col-4" required><br>
          <label>Número de camas de Solteiro</label>
          <input type="number" name="cama_solteiro" min="0"  placeholder="Nº" class="form-control col-4" required><br>
          <label>Número do Quarto</label>
          <input type="number" name="n_quarto" min="1"  placeholder="Insira o número do quarto" class="form-control col-4" required><br>
          <div class="form-check">
            <label>Situação do Quarto</label> <br> 
            <input type="radio" name="ativo" value="S" class="form-check-input" >
            <label>Ativo</label><br>
            <input type="radio" name="ativo" value="N" class="form-check-input" >
            <label>Inativo</label><br>
          </div>
          <label for="descricao">Descrição</label>
          <textarea  class="form-control col-4" name="descricao"  placeholder="Digite a descrição do quarto" required></textarea><br><br>
          <input type="submit" name="btnSalvar" value="Salvar" class="btn btn-primary col-2"> 
        </div>
      </form>
    </main>
  </body>

  </html>
  <?php

  if (isset($_POST['btnSalvar'])) {
      $nome_quarto = $_POST['nome_quarto'];
      $categoria = $_POST['fk_cod_categoria'];
      $cama_casal = $_POST['cama_casal'];
      $cama_solteiro = $_POST['cama_solteiro'];
      $n_quarto = $_POST['n_quarto'];
      $ativo = $_POST['ativo'];
      $descricao = $_POST['descricao'];

      if (empty($nome_quarto) && ($categoria) && ($cama_casal) && ($cama_solteiro) && ($n_quarto) && ($ativo) && ($descricao)) {
          echo "Necessário informar campos obrigatórios";
          exit();
      };

      $sql = "INSERT INTO tb_quartos (nome_quarto, fk_cod_categoria, n_quarto, cama_casal, cama_solteiro, ativo, descricao) VALUES (:nome_quarto, :fk_cod_categoria, :n_quarto, :cama_casal, :cama_solteiro, :ativo, :descricao)"; 

      
      $stmt = $pdo->prepare($sql);
      
      $stmt->bindParam(':nome_quarto', $nome_quarto);
      $stmt->bindParam(':fk_cod_categoria', $categoria);
      $stmt->bindParam(':cama_casal', $cama_casal);
      $stmt->bindParam(':cama_solteiro', $cama_solteiro);
      $stmt->bindParam(':n_quarto', $n_quarto);
      $stmt->bindParam(':ativo', $ativo);
      $stmt->bindParam(':descricao', $descricao);

      
      if ($stmt->execute()) {
       echo "<script> alert('Quarto inserido com sucesso!')</script>";
      } else {
          echo "<script> alert('Erro ao inserir quarto')</script>";
      };
  };
?>