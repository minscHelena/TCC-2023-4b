<?php
session_start();
include_once('conexao.php');
$pdo = conectar();

if(isset($_SESSION['logado'])):
    header("Location: pgAcesso.php");
endif;

if($_SESSION['tipo'] === 'A'){
    $id = $_GET['id'];

    $sqlc = "SELECT * FROM tb_clientes WHERE cod_cliente = :id";
    $stmc = $pdo->prepare($sqlc);
    $stmc->bindParam(':id', $id);
    $stmc->execute();

    if($stmc->rowCount()>0){
        $sqlex = "DELETE FROM tb_clientes WHERE cod_cliente = $id";

        $stmex = $pdo->query($sqlex);
        echo "Cadastro de cliente excluído com sucesso!";
    }else{
        echo "Cliente não encontrado";
    };


    echo "<script> window.location.href = 'conCliente.php';</script>";
}
else{
    echo "<script> alert('Você não tem acesso a essa página')</script>";
};
?>