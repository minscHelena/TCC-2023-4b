===========
WB Datadict
===========

A plugin for MySQL Workbench Community Edition 8.x. This plugin allows
you to generate an HTML data dictionary from a selected schema.

:License: Public domain 2011 `Luis Felipe López Acevedo`_. All rights waived.
:Manual: `English`_, `Español`_



.. REFERENCES
.. _English: https://luis-felipe.gitlab.io/wb-datadict/en/manual/dev/
.. _Español: https://luis-felipe.gitlab.io/wb-datadict/es/manual/dev/
.. _Luis Felipe López Acevedo: https://luis-felipe.gitlab.io/
