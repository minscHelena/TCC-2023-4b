<?php

function conectar()
{

    $host = 'localhost';
    $db = 'ilha_do_sol';
    $user = 'root';
    $password = '';

    $dsn = ("mysql:host=$host;dbname=$db");
    $pdo = new PDO($dsn, $user, $password);
   


    return $pdo;
}

?>
