<?php
        session_start();
        include_once('conexao.php');
        include_once("funcaoData.php");

        $pdo = conectar();

        $query_clientes = "SELECT cod_cliente, nome FROM tb_clientes";
        $result_clientes = $pdo->query($query_clientes);

        if(isset($_SESSION['logado'])):
            header("Location: pgAcesso.php");
        endif;
?>

<!DOCTYPE html>
<html lang="pr-br">
    <head>
        <title>Desmarcar Reserva</title>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link rel="stylesheet" type="text/css" href="/css/styleHomepg.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Comfortaa&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="icon" href="img/opicon1.png">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/jquery.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js">
    </head>
    <body>
    <script>
    function mostrarReservas() {
        var cod_cliente = document.getElementById("cliente").value;
        $.ajax({
            url: "busca_reserva.php",
            method: "POST",
            data: { cod_cliente: cod_cliente },
            success: function(data) {
                $("#reservas").html(data);
            }
        });
    };

    function desmarcarReserva(codAgenda) {
        var confirmacao = confirm("Deseja realmente desmarcar esta reserva?");
        if (confirmacao) {
            $.ajax({
                url: "processar_desmarcar.php",
                method: "POST",
                data: { codAgenda: codAgenda },
                success: function() {
                    mostrarReservas();
                }
            });
        }
    };

    function abrirMenu(){
            document.getElementById('barra_menu').style.width = "250px";
            document.getElementById('cadastro-box').style.marginLeft = "290px";
        
        };
            function fecharMenu(){
            document.getElementById('barra_menu').style.width = "0px";
            document.getElementById('cadastro-box').style.marginLeft = "83px";
        };

        $(document).ready(function(){
                $('.sub-btn').click(function(){
                   $(this).next('.sub-menu').slideToggle();
                   $(this).find('.dropdown').toggleClass('rotate');
                });
            });
    </script>
    <header class="cabecalho">
        <img src="/img/iconeMenu.png" alt="menu" class="icone_menu" onclick="abrirMenu()">
        <img src="img/iconeLogo.png" alt="Logo da Empresa" class="logo">
    </header>
    <div id="barra_menu">
            <img src="/img/iconeMenu.png" alt="menu" class="icone_menu_nav" onclick="fecharMenu()"></a>
            <div class="menu">
            <div class="item"><a href="homepg.php">Início</a></div>
                <div class="item"><a class="sub-btn">Hóspedes<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="insCliente.php" class="sub-item">Cadastrar Cliente</a>
                        <a href="conCliente.php" class="sub-item">Consultar</a>
                        <a href="barraPesquisaCliente.php" class="sub-item">Fazer uma busca</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Quartos<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="insQuarto.php" class="sub-item">Cadastrar Quarto</a>
                        <a href="conQuarto.php" class="sub-item">Consultar</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Categorias<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="inctb_categorias.php" class="sub-item">Cadastrar Categoria</a>
                        <a href="contb_categorias.php" class="sub-item">Consultar</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Reservas<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="geraAgenda.php" class="sub-item">Gerar Agenda</a>
                        <a href="agendar_adm.php" class="sub-item">Realizar Reserva</a>
                        <a href="desmarcar_adm.php" class="sub-item">Desmarcar Reserva</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Relatório<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="/menu_relatorios.php" class="sub-item">Por Status</a>
                    </div>
                </div>
                <div class="item"><a href="logout.php">Sair</a></div>
            </div>
    </div>
        <?php if($_SESSION['tipo'] === 'A'){?>
            <div id="cadastro-box">
            <h2 class="titulo-principal">Desmarcar Reserva</h2>
            <form>
                <div class="form-group">
                    <label>Selecione o Cliente:</label>
                    <select class="form-control col-6" name="cliente" id="cliente" onchange="mostrarReservas()" class="form-control col-4">
                        <option value="">Selecione...</option>
                        <?php
                        foreach ($result_clientes as $row) {
                            echo "<option value=\"{$row['cod_cliente']}\">{$row['nome']}</option>";
                        }
                        ?>
                    </select>
                </div>
            </form>
            <div id="reservas" class="mt-4"></div>
        </div>
    <?php
        }else{
            echo "<script> alert('Você não tem acesso a essa página')</script>";
        };?>
</body>
</html>
