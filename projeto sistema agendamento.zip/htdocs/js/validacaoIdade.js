function validarIdade() {
    var dataNascimento = new Date(document.getElementById("um3").value);
    var hoje = new Date();
    var idade = hoje.getFullYear() - dataNascimento.getFullYear();

    if (hoje.getMonth() < dataNascimento.getMonth() || (hoje.getMonth() === dataNascimento.getMonth() && hoje.getDate() < dataNascimento.getDate())) {
        idade--;
    };

    if (idade < 18) {
        alert("Desculpe, você precisa ter pelo menos 18 anos para se cadastrar.");
        document.getElementById("um3").value = ""; // Limpa a data de nascimento
    };
};

