<?php
session_start();
include_once('conexao.php');

$pdo = conectar();

$id = $_GET['id'];

$sql = "SELECT * FROM tb_categorias WHERE cod_categoria = :id";

$stmc = $pdo->prepare($sql);
$stmc->bindParam(':id', $id);
$stmc->execute();

$re = $stmc->fetch(PDO::FETCH_OBJ);

if(isset($_SESSION['logado'])):
    header("Location: pgAcesso.php");
endif;


?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <title>Alteração de Categorias</title>
    <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link rel="stylesheet" type="text/css" href="/css/styleInserircopy.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Comfortaa&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="icon" href="img/opicon1.png">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/jquery.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js">
    </head>
    <body>
    
    <script>
         function abrirMenu(){
            document.getElementById('barra_menu').style.width = "250px";
            document.getElementById('cadastro-box').style.marginLeft = "290px";
        
        };
        function fecharMenu(){
            document.getElementById('barra_menu').style.width = "0px";
            document.getElementById('cadastro-box').style.marginLeft = "83px";
        };

        $(document).ready(function(){
                $('.sub-btn').click(function(){
                   $(this).next('.sub-menu').slideToggle();
                   $(this).find('.dropdown').toggleClass('rotate');
                });
            });
    </script> 

<header class="cabecalho">
        <img src="/img/iconeMenu.png" alt="menu" class="icone_menu" onclick="abrirMenu()">
        <img src="img/iconeLogo.png" alt="Logo da Empresa" class="logo">
    </header>
    <div id="barra_menu">
            <img src="/img/iconeMenu.png" alt="menu" class="icone_menu_nav" onclick="fecharMenu()"></a>
            <div class="menu">
            <div class="item"><a href="homepg.php">Início</a></div>
                <div class="item"><a class="sub-btn">Hóspedes<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="insCliente.php" class="sub-item">Cadastrar Cliente</a>
                        <a href="conCliente.php" class="sub-item">Consultar</a>
                        <a href="barraPesquisaCliente.php" class="sub-item">Fazer uma busca</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Quartos<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="insQuarto.php" class="sub-item">Cadastrar Quarto</a>
                        <a href="conQuarto.php" class="sub-item">Consultar</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Categorias<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="inctb_categorias.php" class="sub-item">Cadastrar Categoria</a>
                        <a href="contb_categorias.php" class="sub-item">Consultar</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Reservas<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="geraAgenda.php" class="sub-item">Gerar Agenda</a>
                        <a href="agendar_adm.php" class="sub-item">Realizar Reserva</a>
                        <a href="desmarcar_adm.php" class="sub-item">Desmarcar Reserva</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Relatório<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="/menu_relatorios.php" class="sub-item">Por Status</a>
                    </div>
                </div>
                <div class="item"><a href="logout.php">Sair</a></div>
            </div>
    </div>
        <?php
            if($_SESSION['tipo'] === 'A'){?>


            <main id="cadastro-box">
                <h1 class="titulo-principal">Alteração de Categoria</h1>
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Nome</label>
                    <input type="text" class="form-control col-4"name="nome_alt" value="<?php echo $re->nome_categoria; ?>" required><br>
                
                    <label>Valor</label>
                    <input type="number" class="form-control col-4"name="valor_alt" value="<?php echo $re->valor; ?>" required><br>

                    <label>Descrição</label>
                    <input type="text" class="form-control col-4"name="descricao_alt" value="<?php echo $re->descricao_cat; ?>" required><br>

                    <label>Ativo</label>
                    <input type="text" class="form-control col-1"name="ativo_alt" value="<?php echo $re->ativo; ?>" required><br>

                </div>
                <button type="submit" class="btn btn-primary" name="btnAlterar">Alterar</button>
            </form>
        </main>
    <?php }else{
        echo "<script> alert('Você não tem acesso a essa página')</script>";
    };?>   
</body>

</html>
<?php

if (isset($_POST['btnAlterar'])) {

    $nome_alt = $_POST['nome_alt'];
    $valor_alt = $_POST['valor_alt'];
    $descricao_alt = $_POST['descricao_alt'];
    $ativo_alt = $_POST['ativo_alt']; 

    if (empty($nome_alt) &&($valor_alt) &&($descricao_alt) &&($ativo_alt) ) {
        echo "Necessário informar a descricao da categoria";
        exit();
    }

    
    $sqlup = "UPDATE tb_categorias SET nome_categoria = :nome_alt, valor = :valor_alt, descricao_cat= :descricao_alt, ativo = :ativo_alt

    
             WHERE cod_categoria = :id";

   
    $stmup = $pdo->prepare($sqlup);

    
    $stmup->bindParam(':nome_alt', $nome_alt);
    $stmup->bindParam(':valor_alt', $valor_alt);
    $stmup->bindParam(':descricao_alt', $descricao_alt);
    $stmup->bindParam(':ativo_alt', $ativo_alt);

    $stmup->bindParam(':id', $id);

    
    if ($stmup->execute()){
        echo "<script><alert>Alterado com sucesso!</alert></script>";
        echo "<script> window.location.href = 'contb_categorias.php';</script>";
    } else {
        echo "Erro ao alterar!";
    };
    };

?>