<?php
include 'conexao.php';
include 'funcaoData.php'; 

$pdo = conectar();

$quarto = isset($_GET['quarto']) ? $_GET['quarto'] : null;

if ($quarto !== null) {

    $sql = "SELECT cod_agenda, dataag, statusa, cliente FROM tb_agenda WHERE cliente = 0 AND statusa = 'A' AND quarto = :quarto";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':quarto', $quarto, PDO::PARAM_STR);
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($data as $item) {

        echo "<option value='{$item['cod_agenda']}'>" . brmy($item['dataag']) . "</option>";
    }
}
?>