<?php
// Inclua o arquivo de conexão
include_once('conexao.php');
include_once("funcaoData.php");

$pdo = conectar();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["codAgenda"])) {
    $codAgenda = $_POST["codAgenda"];
    $query_desmarcar = "UPDATE tb_agenda SET cliente = 0, statusa = 'A' WHERE cod_agenda = :codAgenda";
    $stmt = $pdo->prepare($query_desmarcar);
    $stmt->bindParam(':codAgenda', $codAgenda, PDO::PARAM_INT);
    $stmt->execute();
}
?>
