<?php
include_once('conexao.php');
include_once("funcaoData.php");

$pdo = conectar();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["cod_cliente"])) {
    $cod_cliente = $_POST["cod_cliente"];

    // Query para obter as reservas do cliente
    $query_reservas = "SELECT cod_agenda, quarto, dataag FROM tb_agenda WHERE cliente = :cod_cliente AND statusa = 'M'";
    $stmt = $pdo->prepare($query_reservas);
    $stmt->bindParam(':cod_cliente', $cod_cliente, PDO::PARAM_INT);
    $stmt->execute();
    $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Construir a tabela de reservas
    echo "<h2>Reservas do Cliente</h2>";
    echo "<table class='table'>";
    echo "
    <thead>
    <tr>
    <th scope='col'>Quarto</th>
    <th scope='col'>Data da Reserva</th>
    <th scope='col'>Desmarcar</th>
    </tr>
    </thead>
    <tbody>";

    foreach ($resultado as $row) {
        echo "<tr>";
        echo "<td>{$row['quarto']}</td>";
        echo "<td>". brmy($row['dataag'])."</td>";
        echo "<td><button type='button' class='btn btn-danger' onclick='desmarcarReserva({$row['cod_agenda']})'>Desmarcar</button></td>";
        echo "</tr>";
    }
    echo "</tbody></table>";
}
?>
