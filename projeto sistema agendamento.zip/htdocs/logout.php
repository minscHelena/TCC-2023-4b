<?php
// cleaning user session
session_start();
unset($_SESSION['cpf']);
unset($_SESSION['tipo']);
header('Location: pgAcesso.php');
?>