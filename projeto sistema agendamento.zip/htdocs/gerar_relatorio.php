<?php
include_once('conexao.php');
include_once("funcaoData.php");

$pdo = conectar();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["status"])) {
    $status = $_POST["status"];

    $query_relatorio = "
        SELECT a.cod_agenda, a.quarto, a.dataag, a.statusa, c.nome
        FROM tb_agenda a
        LEFT JOIN tb_clientes c ON a.cliente = c.cod_cliente
    ";

    if ($status != "Todos") {
        $query_relatorio .= " WHERE a.statusa = :status";
    }

    $stmt = $pdo->prepare($query_relatorio);

    if ($status != "Todos") {$stmt->bindParam(':status', $status, PDO::PARAM_STR);}
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "<h2>Relatório de Reservas</h2>";
        echo "<table class='table'>";
        echo "
            <thead>
                <tr>
                    <th scope='col'>Código da Reserva</th>
                    <th scope='col'>Nome do Cliente</th>
                    <th scope='col'>Quarto</th>
                    <th scope='col'>Data da Reserva</th>
                    <th scope='col'>Status</th>
                </tr>
            </thead><tbody>";

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $linhaClass = ($status == "M") ? 'table-secondary' : 'table-light';

            echo "<tr class='$linhaClass'>";
            echo "<td>{$row['cod_agenda']}</td>";
            echo "<td>{$row['nome']}</td>";
            echo "<td>{$row['quarto']}</td>";
            echo "<td>". brmy($row['dataag'])."</td>";
            echo "<td>{$row['statusa']}</td>";
            echo "</tr>";
        }

        echo "</tbody></table>";
    } else {
        echo "<p>Nenhuma reserva encontrada com o status selecionado.</p>";
    }
}
?>
