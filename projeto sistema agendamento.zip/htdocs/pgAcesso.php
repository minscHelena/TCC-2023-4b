<?php
session_start();
include_once ("conexao.php");

$pdo = conectar();

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <title>Página de Acesso - Ilha Do Sol</title> 

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comfortaa&display=swap" rel="stylesheet">
    <link rel="icon" href="img/opicon1.png">
    <link href="css/bootstrap.min.css">

    <script src="js/bootstrap.js"></script>
    <script src="js/jquery.js"></script>
    <script src="js/jquery.mask.js"></script>
    <script src="js/mascara.js"></script>
    <script src="js/menuLateral.js"></script>   

</head>

<body>
    <!-- <script>
        window.addEventListener('popstate', function () {
        // Impedir que a página volte
        history.pushState(null, '', window.location.href);
        });
    </script> -->
    <header class="cabecalho">
        <!-- <img src="img/iconeMenu.png" alt="menu" class="icone_menu"> -->
        <img src="img/iconeLogo.png" alt="Logo da Empresa" class="logo">
    </header>
    <main>
        <div class="login-box">
            <div class="login-info">
                <h2 class="login-text">Login</h2>
                <div class="form-login">
                    <form method="post" enctype="multipart/form-data">
                        <input class="usuario" type="text" name="cpf" placeholder="Usuário"><br>
                        <input class="senha" type="password" name="senha" placeholder="Senha"><br>
                        <input  class="botaoEnviar" type="submit" name="btnLogin" value="Acessar"><br>
                        <a href="#" class="rec-senha">Esqueci Minha Senha</a>
                    </form>
                </div>
            </div>
        </div>

    </main>
   
</body>

</html>

<?php
if (isset($_POST['btnLogin'])) {

    $usuario = $_POST["cpf"];
    $senha   = md5($_POST["senha"]);
    //$senha   = $_POST["senha"]
    ;

    if (empty($usuario) && empty($senha)) {
        echo "Necessário informar usuario ou senha";
        exit();
    };

    $sql = "SELECT * from tb_clientes WHERE cpf = :cpf AND senha = :senha ";


    $stmt = $pdo->prepare($sql);

    $stmt->bindParam(':cpf', $usuario);
    $stmt->bindParam(':senha', $senha);
    $stmt->execute();

    $resulta = $stmt->fetch(PDO::FETCH_ASSOC); 
    if ($stmt->rowCount() > 0) {
        echo "Usuario logado com sucesso";
        $_SESSION['logado'] == true;
        
        $_SESSION['cpf'] = $resulta['cpf'];
        $_SESSION['tipo'] = $resulta['tipo'];
        
        //mandar pra outra pagina
        header("Location: homepg.php");
    }else {
        echo "Usuario ou Senha Invalido";
    };

    // if (!isset($_SESSION['logged'])) {
    //     header('Location: index.php');
    // }
};
?>