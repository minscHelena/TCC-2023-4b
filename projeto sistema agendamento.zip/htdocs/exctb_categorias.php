<?php
session_start();
include_once('conexao.php');

if(isset($_SESSION['logado'])):
    header("Location: pgAcesso.php");
endif;

$pdo = conectar();

$id = $_GET['id'];

if($_SESSION['tipo'] === 'A'){
    $sqlc = "SELECT * FROM tb_categorias WHERE cod_categoria = :id";
    $stmc = $pdo->prepare($sqlc);
    $stmc->bindParam(':id', $id);
    $stmc->execute();

    if ($stmc->rowCount() > 0) {
        $sqlex = "DELETE FROM tb_categorias WHERE cod_categoria = $id";
        $stmex = $pdo->query($sqlex);
        echo "Categoria excluída com sucesso!";
    } else {
        echo "Categoria não encontrada!";
    }

    echo "<script> window.location.href = 'contb_categorias.php';</script>";
}
else{
    echo "<script> alert('Você não tem acesso a essa página')</script>";
}; 
?>