<?php
session_start();
include_once('conexao.php');
$pdo = conectar();

$id = $_GET['id'];

$sql = "SELECT * FROM tb_clientes WHERE cod_cliente = :id";
$stmtc = $pdo->prepare($sql);
$stmtc->bindParam(':id', $id);
$stmtc->execute();
$re = $stmtc->fetch(PDO::FETCH_OBJ);

$cidades = "SELECT * FROM tb_cidades";
$stmt = $pdo->prepare($cidades);
$stmt->execute();
$linhas = $stmt->fetchAll(PDO::FETCH_ASSOC);


if(isset($_SESSION['logado'])):
    header("Location: pgAcesso.php");
endif;

?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>Alterar Cadastro de Clientes</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link rel="stylesheet" type="text/css" href="/css/styleInserircopy.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Comfortaa&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="icon" href="img/opicon1.png">
        <script src="js/validacaoIdade.js"></script>


        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/jquery.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js">
    </head>
    
<body>
    <script>
        function abrirMenu(){
            document.getElementById('barra_menu').style.width = "250px";
            document.getElementById('cadastro-box').style.marginLeft = "290px";
        
        };
        function fecharMenu(){
            document.getElementById('barra_menu').style.width = "0px";
            document.getElementById('cadastro-box').style.marginLeft = "83px";
        };

        $(document).ready(function(){
                $('.sub-btn').click(function(){
                   $(this).next('.sub-menu').slideToggle();
                   $(this).find('.dropdown').toggleClass('rotate');
                });
            });
    </script> 

<header class="cabecalho">
        <img src="/img/iconeMenu.png" alt="menu" class="icone_menu" onclick="abrirMenu()">
        <img src="img/iconeLogo.png" alt="Logo da Empresa" class="logo">
    </header>
    <div id="barra_menu">
            <img src="/img/iconeMenu.png" alt="menu" class="icone_menu_nav" onclick="fecharMenu()"></a>
            <div class="menu">
            <div class="item"><a href="homepg.php">Início</a></div>
                <div class="item"><a class="sub-btn">Hóspedes<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="insCliente.php" class="sub-item">Cadastrar Cliente</a>
                        <a href="conCliente.php" class="sub-item">Consultar</a>
                        <a href="barraPesquisaCliente.php" class="sub-item">Fazer uma busca</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Quartos<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="insQuarto.php" class="sub-item">Cadastrar Quarto</a>
                        <a href="conQuarto.php" class="sub-item">Consultar</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Categorias<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="inctb_categorias.php" class="sub-item">Cadastrar Categoria</a>
                        <a href="contb_categorias.php" class="sub-item">Consultar</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Reservas<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="geraAgenda.php" class="sub-item">Gerar Agenda</a>
                        <a href="agendar_adm.php" class="sub-item">Realizar Reserva</a>
                        <a href="desmarcar_adm.php" class="sub-item">Desmarcar Reserva</a>
                    </div>
                </div>
                <div class="item"><a class="sub-btn">Relatório<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white" class="bi bi-chevron-down dropdown" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg></a>
                    <div class="sub-menu">
                        <a href="/menu_relatorios.php" class="sub-item">Por Status</a>
                    </div>
                </div>
                <div class="item"><a href="logout.php">Sair</a></div>
            </div>
    </div>
        <?php
            if($_SESSION['tipo'] === 'A'){?>

            <main id="cadastro-box">
                <h1 class="titulo-principal">Alterar Dados do Cliente</h1>
            <form method="POST" enctype="multipart/form-data" class="ml-5">
                <div class="form-group">
                    <label>Nome</label><br>
                    <input type="text" class="form-control col-4"name="nome_alt" value="<?php echo $re->nome;?>" required> <br>
                    <label>CPF</label><br>
                    <input type="number" class=" form-control col-4"name="cpf_alt" value="<?php echo $re->cpf;?>" required> <br>
                    <label>Telefone</label><br>
                    <input type="tel" class=" form-control col-4"name="telefone_alt" value="<?php echo $re->telefone;?>" required><br>
                    <label>E-mail</label><br>
                    <input type="text" class="form-control col-4"name="email_alt" value="<?php echo $re->email;?>" required><br>
                    <label>Data de Nascimento</label><br>
                    <input type="date" class=" form-control col-2"name="data_nasc_alt" value="<?php echo $re->data_nasc;?>" onchange="validarIdade()" required><br>
                    <label>Cidade</label><br>
                    <select name="fk_cod_cidade_alt" class="form-control col-4"  value="<?php echo $re->fk_cod_cidade;?>" required>
                    <option>Selecione</option>
                        <?php foreach ($linhas as $l) { ?>
                            <option value="<?php echo $l['cod_cidade']; ?>"><?php echo $l['nome_cidade'];?></option>
                        <?php } ?>
                    </select><br> 
                    <label>Tipo</label><br>
                    <input type="text" class="form-control col-1"name="tipo_alt" value="<?php echo $re->tipo;?>"><br>
                    <label>Ativo</label><br>
                    <input type="text" class="form-control col-1"name="ativo_alt" value="<?php echo $re->ativo;?>"><br>
                    <label>Senha</label><br>
                    <input type="password" class="form-control col-4"name="senha_alt" value="<?php echo $re->senha;?>"><br>
                

                </div>
                <button type="submit" class="btn btn-primary" name="btnAlterar">Alterar</button>
            </form>
            </main> 
        <?php }else{
             echo "<script> alert('Você não tem acesso a essa página')</script>";
        };?>     
   </body>
</html>
<?php
    if(isset($_POST['btnAlterar'])){
        $nome_alt = $_POST['nome_alt'];
        $cpf_alt = $_POST['cpf_alt'];
        $telefone_alt = $_POST['telefone_alt'];
        $email_alt = $_POST['email_alt'];
        $data_nasc_alt = $_POST['data_nasc_alt'];
        $cidades = $_POST['fk_cod_cidade_alt'];
        $tipo_alt = $_POST['tipo_alt'];
        $senha_alt = md5($_POST['senha_alt']);
        $ativo_alt = $_POST['ativo_alt'];

        $data_nascimento_dt = new DateTime($data_nasc);
        $hoje = new DateTime();
        $idade = $hoje->diff($data_nascimento_dt)->y;

        if ($idade < 18) {
        $message = 'Desculpe, você precisa ter pelo menos 18 anos para se cadastrar.';
        };
       
        if(empty($nome_alt) && ($cpf_alt) && ($telefone_alt) && ($email_alt) && ($data_nasc_alt) && ($tipo_alt) && ($tipo_alt) && ($ativo_alt) && ($senha_alt)){
            echo "Necessário preencher todos os campos!";
            exit();
        };

        $sqlup = "UPDATE tb_clientes SET fk_cod_cidade = :fk_cod_cidade_alt, nome = :nome_alt, cpf= :cpf_alt, telefone = :telefone_alt, email = :email_alt, data_nasc = :data_nasc_alt, tipo = :tipo_alt, senha = :senha_alt, ativo = :ativo_alt WHERE cod_cliente = :id";
        $stmup = $pdo->prepare($sqlup);

        $stmup->bindParam(':nome_alt', $nome_alt);
        $stmup->bindParam(':cpf_alt', $cpf_alt);
        $stmup->bindParam(':telefone_alt', $telefone_alt);
        $stmup->bindParam(':email_alt', $email_alt);
        $stmup->bindParam(':data_nasc_alt', $data_nasc_alt);
        $stmup->bindParam(':fk_cod_cidade_alt', $cidades);
        $stmup->bindParam(':tipo_alt', $tipo_alt);
        $stmup->bindParam(':senha_alt', $senha_alt);
        $stmup->bindParam(':ativo_alt', $ativo_alt);
        $stmup->bindParam(':id',$id);

        function brmy($data_nasc_alt)
        {
            $dataa = implode("/", array_reverse(explode("-", $data_nasc_alt)));
            return $dataa;
        };

        function mybr($data_nasc_alt)
        {
            $datam = implode("-", array_reverse(explode("/", $data_nasc_alt)));
            return $datam;
        };

    
        if($stmup->execute()){
            echo "<script><alert>Dados do cliente alterados com sucesso!</alert></script>";
            echo "<script> window.location.href = 'conCliente.php';</script>";
        }else{
            echo "Erro ao realizar a alteração.";
        };
    };
?>
