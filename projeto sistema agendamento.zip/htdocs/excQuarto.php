<?php
session_start();
include_once('conexao.php');

if(isset($_SESSION['logado'])):
    header("Location: pgAcesso.php");
endif;

$pdo = conectar();
if($_SESSION['tipo'] === 'A'){
    $id = $_GET['id'];

    $sqlc = "SELECT * FROM tb_quartos WHERE cod_quarto = :id";
    $stmc = $pdo->prepare($sqlc);
    $stmc->bindParam(':id', $id);
    $stmc->execute();

    if ($stmc->rowCount() > 0) {
        $sqlex = "DELETE FROM tb_quartos WHERE cod_quarto = $id";
        $stmex = $pdo->query($sqlex);
        echo "Categoria excluída com sucesso!";
    } else {
        echo "Categoria não encontrada!";
    }


    echo "<script> window.location.href = 'conQuarto.php';</script>";
}
else{
    echo "<script> alert('Você não tem acesso a essa página')</script>";
};
?>